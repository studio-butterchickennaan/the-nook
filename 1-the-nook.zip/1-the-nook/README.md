# 1-the nook

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/LOW-EN-YU-S1-04/pen/01a10a4e-4bdc-7668-aedf-bd274c289e93](https://codepen.io/editor/LOW-EN-YU-S1-04/pen/01a10a4e-4bdc-7668-aedf-bd274c289e93).

